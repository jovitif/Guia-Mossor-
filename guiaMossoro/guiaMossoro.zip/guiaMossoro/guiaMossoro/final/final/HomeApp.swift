//
//  finalApp.swift
//  final
//
//  Created by Pablo on 02/11/23.
//

import SwiftUI

@main
struct HomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
