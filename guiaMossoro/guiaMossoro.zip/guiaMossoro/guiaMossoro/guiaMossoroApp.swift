//
//  guiaMossoroApp.swift
//  guiaMossoro
//
//  Created by Student05 on 30/10/23.
//

import SwiftUI

@main
struct guiaMossoroApp: App {
    var body: some Scene {
        WindowGroup {
            Home()
        }
    }
}
